package org.softwood.people


import grails.test.mixin.integration.Integration
import grails.transaction.*
import spock.lang.*

@Integration
@Rollback
class PersonIntegrationSpec extends Specification {

    def setup() {
    }

    def cleanup() {
    }

    void "test create pserson"() {

        given: "we create person "

        def person = new Person (firstName:"will", uid: "will" )

        when : "user is saved"
        assert person.validate() == true
        person.save (failOnError: true)

        then: "check change on database"
        person.id
        person.get (person.id).firstName == "will"

        /*expect:"fix me"
            true == false */
    }
}
