package org.softwood.people

/**
 * Created by William on 31/05/2015.
 */
class Person {

    String  libraryNumber
    String  uid
    String  password
    int     sequenceNumber
    String  firstName
    String  lastName
    int     age
    String  gender  //make enumeration
    String  className
    String  yearGroup
    String  schoolHouseName
    boolean accountEnabled = true
    Date    dateCreated
    Date    lastUpdated
    Date    dateCeased

    static constraints = {
        libraryNumber size: 3..20, unique : true, nullable : true  //consider nullable?
        uid size : 4..10, nullable : false
        password size : 4..20, nullable : true  //change later
        sequenceNumber ()
        firstName nullable : false
        lastName  nullable : true // chnage later
        age ()
        gender nullable : true
        className nullable : true
        yearGroup nullable : true
        schoolHouseName nullable : true
        accountEnabled ()
        dateCreated ()
        lastUpdated ()
        dateCeased nullable : true

    }
}
